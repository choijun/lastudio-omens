<?php
/**
 * After Container template.
 *
 * @package Astrids WordPress theme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
} ?>
            </div>
        </div>
    </div>
</main>